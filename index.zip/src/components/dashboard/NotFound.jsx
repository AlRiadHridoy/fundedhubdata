<template>
  <h1>NotFound Page</h1>
</template>

<script>
export default {
  name: "NotFound"
}
</script>

<style scoped>

</style>