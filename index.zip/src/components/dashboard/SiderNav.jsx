import { Link } from "react-router-dom";

import { mainLogo } from "../../ui/images";

export default function SiderNav() {
  return (
    <aside className="sidebar">
      <div className="logo text-center h-[80px] flex items-center justify-center">
        <Link to="/">
          <img className="inline-block w-[120px]" src={mainLogo} alt="logo" />
        </Link>
      </div>
      <div className="lg:hidden flex flex-wrap flex-col items-center justify-center">
        <img
          className="w-[55px] h-[55px] rounded-full"
          src="/assets/img/author/author.jpeg"
          alt="author"
        />
        <h4 className="text-white text-[15px] mt-[8px]">mikha dev</h4>
        <p className="text-primary text-[12px] mt-[8px]">mikha.dev@gmail.com</p>
      </div>
      <div className="main-menu">
        <ul className="nav">
          <li className="nav-item">
            <Link to="/" className="nav-link group">
              <svg
                className="nav-icon"
                focusable="false"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"></path>
              </svg>
              <span className="text">Dashboard</span>
            </Link>
          </li>
          <li className="nav-item">
            <Link to="./trading-overview" className="nav-link group">
              <svg
                className="nav-icon"
                focusable="false"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z"></path>
              </svg>
              <span className="text">Trading Overview</span>
            </Link>
          </li>

          <li className="nav-item">
            <Link to="./withdraw" className="nav-link group">
              <svg
                className="nav-icon"
                focusable="false"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1.41 16.09V20h-2.67v-1.93c-1.71-.36-3.16-1.46-3.27-3.4h1.96c.1 1.05.82 1.87 2.65 1.87 1.96 0 2.4-.98 2.4-1.59 0-.83-.44-1.61-2.67-2.14-2.48-.6-4.18-1.62-4.18-3.67 0-1.72 1.39-2.84 3.11-3.21V4h2.67v1.95c1.86.45 2.79 1.86 2.85 3.39H14.3c-.05-1.11-.64-1.87-2.22-1.87-1.5 0-2.4.68-2.4 1.64 0 .84.65 1.39 2.67 1.91s4.18 1.39 4.18 3.91c-.01 1.83-1.38 2.83-3.12 3.16z"></path>
              </svg>
              <span className="text">Withdraw</span>
            </Link>
          </li>
          <li className="nav-item">
            <Link to="./top-up-reset" className="nav-link group">
              <svg
                className="nav-icon"
                focusable="false"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path d="M11 17h2v-1h1c.55 0 1-.45 1-1v-3c0-.55-.45-1-1-1h-3v-1h4V8h-2V7h-2v1h-1c-.55 0-1 .45-1 1v3c0 .55.45 1 1 1h3v1H9v2h2v1zm9-13H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4V6h16v12z"></path>
              </svg>
              <span className="text">Top-up & Reset</span>
            </Link>
          </li>
          <li className="nav-item">
            <Link to="./billing" className="nav-link group">
              <svg
                className="nav-icon"
                focusable="false"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path d="M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"></path>
              </svg>
              <span className="text">Billing</span>
            </Link>
          </li>
          <li className="nav-item">
            <Link to="/news-calendar" className="nav-link group">
              <svg
                className="nav-icon"
                focusable="false"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path d="M9 11H7v2h2v-2zm4 0h-2v2h2v-2zm4 0h-2v2h2v-2zm2-7h-1V2h-2v2H8V2H6v2H5c-1.11 0-1.99.9-1.99 2L3 20c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V9h14v11z"></path>
              </svg>
              <span className="text">News Calendar</span>
            </Link>
          </li>
          <li className="nav-item">
            <Link to="/help" className="nav-link group">
              <svg
                className="nav-icon"
                focusable="false"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path d="M11.5 2C6.81 2 3 5.81 3 10.5S6.81 19 11.5 19h.5v3c4.86-2.34 8-7 8-11.5C20 5.81 16.19 2 11.5 2zm1 14.5h-2v-2h2v2zm0-3.5h-2c0-3.25 3-3 3-5 0-1.1-.9-2-2-2s-2 .9-2 2h-2c0-2.21 1.79-4 4-4s4 1.79 4 4c0 2.5-3 2.75-3 5z"></path>
              </svg>
              <span className="text">Help</span>
            </Link>
          </li>
          <li className="nav-item">
            <Link to="/courses" className="nav-link group">
              <svg
                className="nav-icon"
                fill="none"
                strokeWidth="1.5"
                stroke="currentColor"
                focusable="false"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.348a1.125 1.125 0 010 1.971l-11.54 6.347a1.125 1.125 0 01-1.667-.985V5.653z"
                />
              </svg>
              <span className="text">Courses</span>
            </Link>
          </li>
        </ul>
      </div>
    </aside>
  );
}
