import { useEffect, useState, useRef } from "react";
import Footer from "../components/Footer";
import Navbar from "../components/Navbar";
import { Link, useLocation } from "react-router-dom";

import DashNav from "../components/dashboard/dashNav";
import SiderNav from "../components/dashboard/SiderNav";

import {
  footerBg,
  tringle,
  authorTwo,
  author,
  mainLogo,
  shapeGreen,
  shapeRed,
  shapeBlue,
} from "../ui/images";
import DbCollaps from "../components/DbCollaps";

// chart
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

export default function Dashboard() {
  const [paraHeight, setparaHeight] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const [disWith, setDisWith] = useState({
    top: 30,
    right: 30,
    left: -20,
    bottom: -5,
  });
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  useEffect(() => {
    if (screen.width > 560) {
      setDisWith({
        top: 30,
        right: 30,
        left: 15,
        bottom: 10,
      });
    }
  }, []);

  const data = [
    {
      name: "1",
      pv: 1.5,
      amt: 2,
    },
    {
      name: "2",
      pv: 3,
      amt: 2,
    },
    {
      name: "3",
      pv: 5,
      amt: 2,
    },
    {
      name: "4",
      pv: 7,
      amt: 2,
    },
    {
      name: "5",
      pv: 1,
      amt: 2,
    },
    {
      name: "6",
      pv: 9,
      amt: 2,
    },
    {
      name: "7",
      pv: 4,
      amt: 2,
    },
    {
      name: "8",
      pv: 8,
      amt: 2,
    },
    {
      name: "9",
      pv: 6,
      amt: 2,
    },
    {
      name: "10",
      pv: 8,
      amt: 2,
    },
  ];

  return (
    <>
      <DashNav />
      <SiderNav />
    
      <section className="dashboard relative">
        <div className="wrapper ">
          <div className="menu-overlay :className=isMenubar ? 'fixed left-0 top-0 w-full h-full bg-dark/80 cursor-pointer' : 'hidden' @click=isMenubar = !isMenubar z-10 relative"></div>

          <main className="content-wrapper :className=isSidebar ? 'content-wrapper' : 'xl:!pl-[73px]'">
            <div className="inner-content">
              <div className="breadcrumb-wrap">
                <div className="breadcrumb-title">
                  <svg
                    className="breadcrumb-icon"
                    focusable="false"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                  >
                    <path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"></path>
                  </svg>
                  Dashboard
                </div>
              </div>
              <div className="dashboard-wrapper">
                <div className="flex flex-wrap">
                  <div className="w-full px-[15px]">
                    <div className=" grid sm:grid-cols-2 lg:grid-cols-3 gap-6 w-full">
                      <div className="w-full">
                        <div className="dashboard-card">
                          <div className="d-icon bg-primary">
                            <svg
                              className="icon"
                              focusable="false"
                              viewBox="0 0 24 24"
                              aria-hidden="true"
                            >
                              <path d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"></path>
                            </svg>
                          </div>
                          <div className="content">
                            <h2>$8500.00</h2>
                            <p>profit/loss</p>
                          </div>
                          <div className="shape-bg">
                            <img
                              className="w-full"
                              src={shapeGreen}
                              alt="shape"
                            />
                          </div>
                        </div>
                      </div>
                      <div className=" w-full ">
                        <div className="dashboard-card">
                          <div className="d-icon bg-primary">
                            <svg
                              className="icon"
                              focusable="false"
                              viewBox="0 0 24 24"
                              aria-hidden="true"
                            >
                              <path d="M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z"></path>
                            </svg>
                          </div>
                          <div className="content">
                            <h2>$0.00</h2>
                            <p>drawdown</p>
                          </div>
                          <div className="shape-bg">
                            <img
                              className="w-full"
                              src={shapeRed}
                              alt="shape"
                            />
                          </div>
                        </div>
                      </div>
                      <div className=" w-full">
                        <div className="dashboard-card">
                          <div className="d-icon bg-primary">
                            <svg
                              className="icon"
                              focusable="false"
                              viewBox="0 0 24 24"
                              aria-hidden="true"
                            >
                              <path d="M9 11H7v2h2v-2zm4 0h-2v2h2v-2zm4 0h-2v2h2v-2zm2-7h-1V2h-2v2H8V2H6v2H5c-1.11 0-1.99.9-1.99 2L3 20c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V9h14v11z"></path>
                            </svg>
                          </div>
                          <div className="content">
                            <h2>11 Days</h2>
                            <p>trading days</p>
                          </div>
                          <div className="shape-bg">
                            <img
                              className="w-full"
                              src={shapeBlue}
                              alt="shape"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-wrap mx-[-15px]">
                      <div className="w-full px-[15px]">
                        <div className="card-wrap">
                          <h3 className="card-title">Account Details</h3>
                          <div className="content">
                            <div className="account-info">
                              <div className="account-info-top">
                                <div className="info-item">
                                  <h4>Login</h4>
                                  <p>0000000</p>
                                </div>
                                <div className="info-item">
                                  <h4>Password</h4>
                                  <div className="pass-show">
                                    <p>********</p>
                                    <div className="pass-icon ml-[20px]">
                                      <svg
                                        className="icon w-[14px] h-[14px] dark:fill-white"
                                        focusable="false"
                                        viewBox="0 0 24 24"
                                        aria-hidden="true"
                                      >
                                        <path d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2zm4.31-.78l3.15 3.15.02-.16c0-1.66-1.34-3-3-3l-.17.01z"></path>
                                      </svg>
                                    </div>
                                  </div>
                                </div>
                                <div className="info-item">
                                  <h4>MT4 Server</h4>
                                  <p>MT4 Server-Demo</p>
                                </div>
                                <div className="info-item">
                                  <h4>Balance</h4>
                                  <p>$50000.00</p>
                                </div>
                                <div className="info-item">
                                  <h4>Funded Plan</h4>
                                  <p>Express - 50k</p>
                                </div>
                              </div>
                              <div className="account-info-bottom mt-[40px]">
                                <h4>Trading Cycle Details</h4>
                                <div className="flex md:flex-nowrap flex-wrap items-center md:gap-[40px] gap-[20px]">
                                  <p>
                                    <span className="text-[16px] font-bold">
                                      Start Date:
                                    </span>{" "}
                                    Sep 25, 2022
                                  </p>
                                  <p>
                                    <span className="text-[16px] font-bold">
                                      End Date:
                                    </span>{" "}
                                    Oct 25, 2022
                                  </p>
                                  <a
                                    href="#"
                                    className="account-info-btn group"
                                  >
                                    <svg
                                      className="icon w-[20px] h-[20px] fill-white mr-[5px] dark:group-hover:fill-dark"
                                      focusable="false"
                                      viewBox="0 0 24 24"
                                      aria-hidden="true"
                                    >
                                      <path d="M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z"></path>
                                    </svg>
                                    Trading Details
                                  </a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-wrap mx-[-15px] relative">
                      <div className="w-full px-[15px] z-10 relative">
                        <div className="card-wrap">
                          <h3 className="card-title z-10 relative">
                            Trading Growth Curve
                          </h3>
                          <div className="content">
                            {/* Chart section */}
                            <div className="chart relative z-10 grid gap-4 py-2 px-5 border border-primary/60 rounded-xl">
                              <div className="heading font-codeProBold flex pl-5 items-center bg-main-bg rounded-md py-2">
                                <h4>Chart:</h4>
                              </div>

                              {/* chart */}
                              <div className="bg-primary/10 rounded-lg mb-2 h-[300px] sm:h-[250px] md:h-[320px]">
                                <ResponsiveContainer height="100%">
                                  <LineChart data={data} margin={disWith}>
                                    <XAxis className="theXaxis" />
                                    <YAxis />
                                    <Tooltip />
                                    <Legend />
                                    <Line dataKey="pv" stroke="#C7B3FC" />
                                  </LineChart>
                                </ResponsiveContainer>
                              </div>
                            </div>

                            {/* Triangles */}
                            {/* triangle */}
                            <img
                              className="triangle absolute -bottom-[20%] -right-[10%]  w-[50rem] rotate-[80deg] opacity-[0.09]"
                              src={tringle}
                              alt="tringle"
                            />
                            {/* triangle */}
                            <img
                              className="triangle absolute bottom-[20rem] -left-[10%]  w-[50rem] rotate-[80deg] opacity-[0.09]"
                              src={tringle}
                              alt="tringle"
                            />
                            {/* triangle */}
                            <img
                              className="triangle absolute -top-[10%] -right-[20%]  w-[70rem] rotate-[80deg] opacity-[0.07]"
                              src={tringle}
                              alt="tringle"
                            />
                            {/* triangle */}
                            <img
                              className="triangle absolute -bottom-[5%] -right-[20%]  w-[50rem] rotate-[80deg] opacity-[0.05]"
                              src={tringle}
                              alt="tringle"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>

        {/* triangle */}
        <img
          className="triangle absolute -bottom-[20%] -left-[10%]  w-[50rem] rotate-[80deg] opacity-[0.19]"
          src={tringle}
          alt="tringle"
        />
        {/* triangle */}
        <img
          className="triangle absolute bottom-[20rem] -left-[15rem]  w-[50rem] rotate-[80deg] opacity-[0.09]"
          src={tringle}
          alt="tringle"
        />
        {/* triangle */}
        <img
          className="triangle absolute -top-[10%] -right-[20%]  w-[70rem] rotate-[80deg] opacity-[0.13]"
          src={tringle}
          alt="tringle"
        />
        {/* triangle */}
        <img
          className="triangle absolute -bottom-[5%] -right-[20%]  w-[50rem] rotate-[80deg] opacity-[0.17]"
          src={tringle}
          alt="tringle"
        />
      </section>
      <Footer />
    </>
  );
}
