import mainLogo from "../assets/images/logo.png";
import dashboard from "../assets/images/dashboard.webp";
import discord from "../assets/images/discord.svg";
import arrow from "../assets/images/arrow.svg";
import globe from "../assets/images/globe.png";
import footerBg from "../assets/images/footer-logo.png";
import tringle from "../assets/images/triangle.svg";
import favicon from "../assets/images/favicon.png";
import copy from "../assets/images/copy.svg";
import applePlay from "../assets/images/apple-pay.png";
import googlePay from "../assets/images/google-pay.png";
import btcPay from "../assets/images/btc-pay.png";
import tick from "../assets/images/tick.svg";
import mobile from "../assets/images/mobile.webp";

// Dashboard Images
import authorTwo from "../assets/images/dashboard/author/author-2.jpeg";
import author from "../assets/images/dashboard/author/author.jpeg";
import shapeBlue from "../assets/images/dashboard/shape/shape-blue.png";
import shapeRed from "../assets/images/dashboard/shape/shape-red.png";
import shapeGreen from "../assets/images/dashboard/shape/shape-green.png";

import thumbHistory from "../assets/images/dashboard/thumb/thumb-11.png";
// import  from "../assets/images/dashboard/";
// import  from "../assets/images/dashboard/";
// import  from "../assets/images/dashboard/";
// import  from "../assets/images/dashboard/";

export {
  mainLogo,
  dashboard,
  discord,
  arrow,
  globe,
  footerBg,
  tringle,
  copy,
  applePlay,
  googlePay,
  btcPay,
  tick,
  mobile,
  favicon,
  // Dashboard
  authorTwo,
  author,
  shapeBlue,
  shapeRed,
  shapeGreen,
  thumbHistory,
};
