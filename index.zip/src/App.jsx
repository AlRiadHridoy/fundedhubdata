import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Registration from "./pages/Registration";
import Dashboard from "./pages/Dashboard";
import Contact from "./pages/Contact";

import Checkout from "./pages/Checkout";
import TradingOverview from "./components/dashboard/TradingOverview";

import "./App.css";
import "./dashboard.css";
import Billing from "./components/dashboard/Billing";
function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/billing" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/registration" element={<Registration />} />
          <Route path="/" element={<Billing />} />
          <Route path="/dashboard/*" element={<Dashboard />} />
          <Route path="/trading-overview" element={<TradingOverview />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/checkout" element={<Checkout />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
